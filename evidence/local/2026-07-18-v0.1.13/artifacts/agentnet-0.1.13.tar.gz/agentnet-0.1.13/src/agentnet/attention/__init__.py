"""Exceptional notification policy."""

