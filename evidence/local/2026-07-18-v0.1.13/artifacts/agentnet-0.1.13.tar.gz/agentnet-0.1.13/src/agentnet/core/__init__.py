"""Transactional corporate core composition."""

