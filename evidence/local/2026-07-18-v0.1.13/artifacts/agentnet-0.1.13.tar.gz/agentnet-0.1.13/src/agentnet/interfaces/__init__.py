"""Replaceable component contracts."""

