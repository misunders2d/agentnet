# Requirements Status

Snapshot: 2026-08-09. This is an implementation/evidence ledger, not a release
certificate. It contains the exact 85 stable requirement IDs from the preserved
requirements reference. PD-001 through PD-011 are listed separately because
they are accountable policy decisions, not additional requirements.

Observed evidence, with current uncommitted candidate results separated from
published and historical release evidence:

- Published `0.1.19` contains the fixed atomic `BootstrapGrantPlan`, dedicated
  selector-free C0 service, exact active harness/credential-set invalidation,
  authoritative seven-fact/event/receipt replay validation, no-model owner
  responder, and exact five-power cleanup. Independent public package checks
  passed. The remote deployment peer reported that its pre-migration preflight
  found a deterministic PostgreSQL catalog verifier defect before mutation: psycopg rejected PostgreSQL literal `%I` in
  a parameterized query. The remote deployment peer reported no migration,
  restart, runtime switch, enrollment, authority, message, or A2A change and
  reported live Core and Approval still on `0.1.18` with schema v3. This
  candidate's retained local evidence does not independently verify that remote
  runtime report.
- Published `0.1.20` corrected the psycopg `%I` expression, but independent
  read-only PostgreSQL 18.4 preflight exposed exact-catalog renderer gaps for
  `contype='n'` NOT NULL rows, CHECK definitions, and partial-index predicates.
  The peer stopped before mutation; `0.1.20` remains immutable and undeployable.
- Published `0.1.21` reconciled every PostgreSQL 18 NOT NULL row against
  migration-derived required columns and structurally compared bounded
  CHECK/index predicates, but exact public-artifact startup on PostgreSQL 18.4
  failed because the S4 constraint-count query used reserved table alias
  `constraint`. The peer stopped the rollout and later clean-uninstalled
  AgentNet under owner direction. Pi, A2A, and the PostgreSQL service remained
  unchanged; `0.1.21` is immutable and undeployable.
- Published `0.1.22` changed only that query alias to non-keyword `con` and added
  a focused regression. Migration SQL/checksums, catalog expectations, C0
  authority, identity, messaging, cleanup, and A2A semantics remained unchanged.
  Hermetic PostgreSQL checks reported **78 passed and 7 expected dedicated-database
  skips**; disposable PostgreSQL 18.4 reported **85 passed and 0 skipped**; the
  complete source suite reported **1377 passed and 15 expected host/PostgreSQL
  skips**; and the installed npm-packed candidate reported **1305 passed and 8
  expected non-Linux host skips**. Commit, tag, CI, Sergey-only publication, and
  public-artifact verification completed for that immutable release.
- Tag `v0.1.23` reached the staging workflow, but CI stopped before npm staging
  because one hermetic interruption test mocked `/usr/bin/useradd` on a runner
  without that path. No `0.1.23` package was staged or published.
- Published `0.1.24` retains the reviewed `0.1.23` runtime and changes only that
  fixture to mock AgentNet's validated host-tool resolver. It provides one fixed
  product-owned ordinary-server setup boundary, dedicated locked service
  identities, exact plan/apply digest approval, create-or-exact-match host state,
  and redacted health/readiness evidence; it grants no identity or authority.
- Published `0.1.25` repairs two local JSON-RPC interoperability defects exposed
  by official A2A TCK commit `5996b79f9cefa6fc390980e383e358a66fb9e49e`:
  exact `/rpc` and `/rpc/` aliases avoid POST redirects, and an absent SDK request
  tenant is restored only from an exact verified opaque route binding. Missing or
  spoofed bindings and conflicting tenants fail closed; rejected requests persist
  no event/task/task-event residue; cross-alias retries preserve exact idempotency
  and non-enumerating task lookup. Local A2A reports **57 passed** and the source
  lane excluding installed-live inference and release-manifest self-check reports
  **1386 passed and 15 expected host/PostgreSQL skips**. Focused official JSON-RPC
  reports **3 passed**, but the full MUST lane remains non-green at **50 passed,
  11 failed, 174 skipped**. G04 remains `FAILED`; no requirement, production,
  deployment, cutover, or gate status is promoted by those results.
- Published `0.1.26` repairs ordinary Linux setup convergence.
  Affected stable IDs: `ARC-001`, `ID-001`, `ID-002`, `ID-003`, `ID-006`,
  `SEC-005`, `SEC-007`, `OPS-003`, `OPS-006`, and `OPS-007`. The candidate's
  approval digest v2 binds exact service-visible Node/uv/AgentNet/`systemctl`/
  `useradd` executable paths/content and the full executed AgentNet package-tree
  content identity; semantic
  broker validation and locked preflight precede managed writes; PostgreSQL uses
  one exact service-identity Unix-socket peer gate with parsed-rule and reload-
  freshness evidence; marker v2 uses same-request prior-byte compare-and-swap,
  derives realized-config hashes from stable persisted JSON rather than process-
  randomized set serialization, and never skips realized-state bootstrap. Windows
  CLI import no longer requires Unix account modules. Current local focused
  platform/setup/activation/package/release lane is **152 passed with 9 expected
  non-host platform skips** and the release verifier passes; source regression
  excluding installed-harness and release-manifest gates is **1433 passed with 16
  expected platform/dedicated-PostgreSQL skips**. At commit `58a13dd`, GitHub run
  `30155733937` passed the clean Ubuntu 24.04/PostgreSQL 18 installed-artifact
  plan/blocker/apply/start/stable-retry lifecycle and always-run cleanup; run
  `30155733938` passed package conformance on Ubuntu, macOS, and Windows.
  Immutable tag object `c481d850ba4933abbb77191a763a7c4e0817bc32` resolves to
  commit `a7da3aa945c0b2f25fdb06803b80529f89bf8242`; public npm `gitHead`
  matches. External deployment evidence remains pending; no requirement or gate
  status is promoted.
- Published `0.1.27` communication-only proof candidate affects `ARC-001`,
  `AUTH-001`, `AUTH-002`, `AUTH-004`, `AUTH-007`, `ORG-002`, `ORG-005`,
  `COM-001`, `COM-006`, `COM-007`, `COM-011`, `FILE-001..006`, `AVL-003`,
  `AVL-005`, `AVL-006`, `OPS-003`, `OPS-006`, and `OPS-007`. It adds a
  request-v2 `artifact_mode=disabled` ordinary-server profile with exact
  `offline_custody`, version-disjoint approval/marker evidence, no
  scanner/artifact state, pre-custody artifact denial (including replay), and
  local signed message/conversation/obligation/downward-task evidence through
  `accepted_queued`; request-v1 remains scanner-backed. Constitution and code
  reviews pass. The affected suite reports **215 passed**. `npm run check`
  reports source and two recursively packed generations at **1412 passed with
  16 expected platform/dedicated-PostgreSQL skips**; package, release-verifier,
  and reproducible wheel/sdist checks pass. The unfiltered pre-refresh run
  preserved two installed-harness pin gate failures; no gate is waived. This
  candidate changes no requirement or gate status and supplies no `FILE-*`,
  G13, production, ship, real-network, fresh-laptop enrollment, or native
  cross-host evidence. Hub root-installed verification subsequently exposed
  three portability failures before any setup or network mutation.
- Published `0.1.28` affects `ARC-001`, `SEC-007`, `OPS-006`, and `OPS-007`.
  Python and Node privileged setup-input readers now accumulate bounded short
  reads and compare two content snapshots while retaining metadata/path custody
  checks, so same-size mutation rejection does not depend on filesystem timestamp
  advancement. Launcher tests separately prove structured user-owned and
  root-owned/non-traversable rejection states. Ordinary-user and UID-0
  user-namespace focused lanes each report **7 passed**; server-setup and npm
  conformance report **92 passed** and **10 passed**. The final source and two
  clean recursively packed npm generations each report **1418 passed with 16
  expected platform/dedicated-PostgreSQL skips**; package, release-verifier,
  launcher, recursive-package, and byte-identical wheel/sdist checks pass. Those
  lanes exclude installed-live-inference, subprocess-lifecycle, and
  bake-off-evidence files; the two installed-harness pin failures remain
  non-green and were not rerun or waived. The UID-0 lane is a Linux user
  namespace, not external privileged-host evidence. No requirement or gate
  status is promoted.
- Candidate `0.1.29` affects `ID-002`, `ID-003`, `ID-004`, `AUTH-001`,
  `AUTH-003`, `SEC-002`, `SEC-005`, `OPS-006`, and `OPS-007`. A real public
  `0.1.28` owner Google OIDC attempt exposed pre-claim callback rejection of
  valid unique provider metadata. Shared callback parsing now rejects duplicate
  decoded names globally, separates strict success/error recognized fields,
  ignores only unique unrecognized OAuth extensions, and consumes only the
  exact bound pending owner/enrollment/recovery transaction on provider error
  without token exchange. Existing cookie/state, PKCE, nonce,
  issuer/audience/signature, expiry, replay, and owner-binding checks remain.
  Focused callback checks report `92 passed`; source and both recursively packed
  generations each report `1443 passed, 16 expected skips`; release, package,
  reviewer, and reproducible-build gates pass. The failed callback URL is not
  retried or reused. This repair changes no
  requirement or gate status; real fresh-laptop completion remains external
  evidence.
- Published `0.1.30` affects `OPS-006`, `OPS-007`, `SEC-007`, and the practical `COM-001`/`AVL-005` first-message path. It runs installed verification from a bounded disposable package copy, rejects caller pytest arguments, and requires both a complete package-tree content digest match and no cache/bytecode residue across two recursive packed installations. This changes no requirement or gate status; real Hub setup, fresh-laptop enrollment, native cross-host message, and recipient ACK remain pending.
- Published `0.1.31` affects `ARC-001`, `ID-001..006`, `AUTH-001..004`, `AUTH-007`, `SEC-002`, `SEC-005`, `SEC-007`, `OPS-003`, `OPS-006`, `OPS-007`, and the practical `COM-001`/`COM-011`/`AVL-005` first-message path. It adds fixed browser-only remote activation bound to exact approved OIDC owner identity; purpose-separated automatic Approval possession; exact supported `0.1.28/0.1.30` setup migration and response-loss recovery; status-scoped guided-join polling through fresh Approval-challenge expiry; Core-authenticated terminal replacement with argument-bound v2 state and same-key reuse; enabled-unit reconciliation; and package-only destructive reset under a permanent root-only coordination lock. Latest affected suite reports **344 passed**. Unfiltered local run reports **1625 passed and 16 expected platform/dedicated-PostgreSQL skips**, while two installed-harness pin failures and pre-refresh release-manifest drift remain non-green and unwaived. A packed focused recovery/conformance lane reports **72 passed**, one Pi skill, zero loader diagnostics, and no verification residue. Official source and two recursive packed generations each report **1549 passed and 16 expected skips** with complete package-tree digest/no-residue checks green. Two deterministic builds produced byte-identical wheel/sdist archives. Independent Opus 5 closure reports no blockers and PASS for skill architecture, code security, and Constitution. The first exact untagged Hub artifact installed byte-identically into an inert root-owned prefix and then failed closed before setup because its embedded release bindings were stale; replacement artifact verification and real browser/fresh-laptop message/ACK/revocation evidence remain pending. No requirement or gate status is promoted.
- Published `0.1.32` affects `ARC-001`, `ID-001..006`, `AUTH-001..004`, `AUTH-007`, `COM-001`, `COM-009`, `COM-011`, `AVL-005`, `SEC-002`, `SEC-005`, `SEC-007`, `OPS-003`, `OPS-006`, and `OPS-007`. It adds signed Approval broker readiness through the configured public origin using explicit host trust with certificate/key-log environment denied before setup, authoritative setup reconciliation, Core schema v5 OIDC-begin replay and finite credential-renewal custody, a dedicated package-owned C0 responder, clean current-package attempt custody, and the exact five-unit systemd/reset lifecycle. Exact public-package apply on the Hub failed closed at `setup_marker_conflict` before managed mutation because the active `0.1.31` marker records the released two-unit communication-only profile. It promotes no requirement or gate.
- Published `0.1.35` affects `SEC-007`, `OPS-003`, `OPS-006`, `OPS-007`,
  and the blocked `ID-001..006`/`COM-001`/`COM-011`/`AVL-005` first-message
  path. It preserves atomic 0.1.33 journal succession, exact failed-unit
  reconciliation, and owner-approved same-key expired-credential
  reauthorization. Same-commit cross-platform, clean-server, and real upgrade
  workflows passed before publication. One exact Hub apply then committed the
  marker and PostgreSQL migration but exposed an unsatisfiable setup check:
  canonical strict `VerifiedActor` profiles forbid and never serialize
  `actor.key_id`, while setup required that field. Units remained inactive,
  authority false, and no enrollment or C0 message occurred.
- Published `0.1.37` affects `AUTH-007`, `SEC-007`, `OPS-003`, `OPS-006`,
  `OPS-007`, and the same blocked first-message path. It rejects duplicate/non-finite managed
  profile JSON, strictly parses the canonical actor, verifies current
  domain/harness/credential labels, retains exact profile and P-256 private-key
  custody/readability checks, and removes only the impossible duplicate field
  test. Database-backed credential-to-key binding remains owned by
  `server-agent activate`. It adds only the exact released `0.1.33` five-unit
  marker migration to `0.1.37`, with provenance-checked retained-journal
  recovery; `0.1.34`, `0.1.35`, and direct legacy sources remain rejected.
  Exact public `0.1.37` reached a committed five-unit Hub marker with Core and
  Approval healthy, then failed closed because the public route converged after
  the ordinary 30-attempt probe window. Authority remained false and
  responder/renewal stayed disabled. The two
  installed-harness G01 failures remain non-green and unwaived. It also pins
  accepted owner-only Unix MCP bootstrap sockets with non-inheritable stable
  path descriptors, preserving the pin during retryable renewal but removing
  the locator, closing the pin, stopping retry cycling, and reporting a fixed
  content-free failure code after startup failure or terminal exhaustion.
  Release requires external exact same-commit terminal-green cross-platform, clean-setup, and
  exact released-marker rejection workflow evidence; post-push run IDs are not self-authored into source.
  No requirement or gate is promoted.
- Published `0.1.38` affects `OPS-003`, `OPS-004`, `OPS-006`, `OPS-007`,
  and the blocked `COM-001`/`COM-009`/`COM-011`/`AVL-005` first-message path.
  It gives only public post-restart Approval/Core health and Core readiness the
  existing finite 90-attempt startup bound; exact identity/readiness payload,
  TLS, redirect, and fail-closed checks are unchanged. It admits only the exact
  released `0.1.37` five-unit marker as its source and rejects other releases.
  Its setup/recovery, focused, source, recursive packed, conformance, release,
  deterministic-build, same-commit CI, tag, trusted-stage, and public-package
  checks passed. The remote Hub peer reported from bounded read-only fresh-install
  preflight that its default `Python-urllib/*` User-Agent received HTTP 403 on all
  three public routes; no 0.1.38 Hub installation occurred. That report remains
  corroboration only, not retained reproducible release proof.
- Candidate `0.1.39` affects `AUTH-001`, `AUTH-002`, `AUTH-004`, `AUTH-007`,
  `COM-001`, `COM-006`, `COM-009`, `COM-011`, `AVL-002`, `AVL-005`, `AVL-006`,
  `SEC-003`, `SEC-005`, `SEC-006`, `OPS-003`, `OPS-004`, `OPS-006`, and
  `OPS-007`. It changes health request identity to explicit GET,
  `User-Agent: AgentNet/0.1.39`, and `Accept: application/json` while preserving
  proxy, redirect, TLS, timeout, response, identity/readiness, authority, and
  auxiliary-unit boundaries. It also repairs only the local policy-revision,
  recipient-resolution, and exact custody-acknowledgement seams needed for
  signed `deterministic_only` lab harnesses to use the pre-existing narrow C0
  allowlist; the production policy still rejects those harnesses. A fresh npm
  tarball installed into an unrelated prefix passed a real loopback,
  separate-process local journey: offline recipient until Core restart, exact
  proof-derived attribution, `accepted_local`, idempotent event/obligation and
  receipt convergence, `recipient_committed`, typed obligation completion across
  restarts, fresh refusal after an explicitly non-approved lab credential fixture,
  and temporary-state cleanup. This is H/L-shaped synthetic evidence only; it is
  not `COMPLETED_C0_ROUND_TRIP`, approved revocation/five-power cleanup,
  OIDC/WebAuthn enrollment, ordinary server-agent `COM-002`/`COM-003`,
  PostgreSQL/HA durability, or production proof. It adds no migration edge and
  rejects an exact 0.1.38 release marker. Final source and recursive packed
  counts, deterministic artifacts, and release metadata are refreshed. Exact
  same-commit cross-platform, clean-setup, released-marker rejection, and
  packaged-communication CI remain pending. No requirement or gate is promoted.
- Unpublished corrective `0.1.42` narrows the current candidate to the real
  first-C0 path. Retained evidence at
  `evidence/local/2026-08-04-v0.1.42-c0-live/manifest.json` records one fresh
  real workforce-OIDC and WebAuthn-approved server enrollment, one fresh
  independently stored laptop enrollment, one passkey-approved fixed
  `BootstrapGrantPlan`, terminal `COMPLETED_C0_ROUND_TRIP`, seven distinct
  authoritative C0 facts, and exact revocation of all five temporary
  communication entitlements through five exact-revoke plan items.
  Sanitized query and result evidence is retained at
  `evidence/local/2026-08-04-v0.1.42-c0-live/postconditions.json`, SHA-256
  `518f030c0503f93bcc6e119581c1c4d88c16f6ec06b69addc2768a5c7be2681a`.
  The systemd responder accepted only its package-owned private credential file;
  the bootstrap resolver accepted strict remote-browser evidence without
  weakening local-browser evidence. This is narrow real-enrollment and local
  service evidence for `ID-001`, `ID-002`, `ID-004`, `ID-006`, `AUTH-001`,
  `AUTH-002`, `AUTH-003`, `AUTH-004`, `AUTH-007`, `AUTH-009`, `COM-001`,
  `COM-002`, `COM-003`, `COM-006`, `COM-009`, `AVL-003`, `AVL-005`,
  `AVL-006`, `SEC-003`, and `SEC-005`; it is not a release certificate.
  Broad verification remains non-green: the unfiltered suite reported
  **1747 passed, 16 expected skips, and 3 failed** (two explicit installed
  harness-pin gates plus the pre-release manifest gate); `agentnet verify`
  reported **1665 passed, 16 expected skips, and 1 failed** on the same
  manifest drift; and `scripts/verify_release.py` reported 15 expected
  candidate-versus-retained-`0.1.39` drift findings. No requirement or gate is
  promoted, and publication remains blocked.
  A post-run review found that the dedicated credential reader could block
  before rejecting a FIFO or device. Source revision `52b6941` adds a
  nonblocking descriptor open and a regression that failed before the fix;
  the responder file now reports **23 passed**. This corrective source was not
  deployed for the historical live run, which remains bound to
  `d8884b6c03a0dd38baab03386982aae8ad11dd58`; it therefore requires a fresh
  candidate build and deployment evidence before any release handoff.
  Focused corrective evidence and review closure are retained at
  `evidence/local/2026-08-04-v0.1.42-post-live-corrective/manifest.json`.
- Candidate `0.1.43` packages the corrected source for a fresh same-commit
  release path. It includes strict remote-browser bootstrap evidence,
  byte-preserving P-256 responder credential handling, package-owned systemd
  credential custody, and `O_NONBLOCK` before regular-file validation. Current
  local source verification reports **757 passed and 7 expected dedicated-
  PostgreSQL skips** in the affected lane and **1640 passed and 16 expected
  platform/dedicated-PostgreSQL skips** in the broad source lane. Fresh npm
  tarballs from both recursive generations each repeated that **1640 passed,
  16 expected skips** source lane; the retained-content second generation also
  completed the real loopback Core/separate-client local communication journey
  and left an empty workspace. The candidate evidence manifest records the
  final release-manifest/direct-verifier and retained byte-identical archive
  outcomes. Same-commit CI, immutable tag, npm stage, staged-package remote
  deployment, and publication remain external actions. The `0.1.42` live run
  remains historical evidence only and was not rerun after the descriptor-open
  correction. Affected IDs remain
  `ID-001`, `ID-002`, `ID-004`, `ID-006`, `AUTH-001`, `AUTH-002`, `AUTH-003`,
  `AUTH-004`, `AUTH-007`, `AUTH-009`, `COM-001`, `COM-002`, `COM-003`,
  `COM-006`, `COM-009`, `AVL-003`, `AVL-005`, `AVL-006`, `SEC-003`,
  `SEC-005`, `OPS-003`, and `OPS-006`. No requirement or gate is promoted.
- Candidate `0.1.44` adds the private administration dashboard, durable
  same-principal communication-scope activation, and the parent-owned local
  Manager binding used by ordinary laptop agents. The dashboard is loopback
  only, opens through a one-time browser handoff, revalidates the exact
  harness credential and `console.session.open` authority, binds every
  mutation to a single-use method/path/body token, and stores only
  content-free refresh state. Communication activation requires one fresh
  WebAuthn-UV approval for one exact same-principal harness pair; the resulting
  human entitlements remain current-policy/current-credential scoped and
  independently revocable. The Manager gateway keeps the laptop credential in
  its parent, gives each sandbox child only a short-lived measured local
  capability, and forwards canonical operations as signed AgentNet HTTP
  requests. Local verification reports **329 passed and 7 expected dedicated-
  PostgreSQL skips** in the affected release lane and **1761 passed and 16
  expected platform/dedicated-PostgreSQL skips** in the broad source lane.
  Source plus both clean recursive installed-package generations each report
  **1788 passed and 16 expected skips**; generation 2 also passed the installed-
  byte multiprocess communication gate. Same-commit CI, staging, and remote
  deployment evidence remain required.
  Affected IDs are `ID-006`, `AUTH-001`,
  `AUTH-002`, `AUTH-003`, `AUTH-004`, `AUTH-007`, `AUTH-009`, `COM-001`,
  `COM-002`, `COM-003`, `COM-006`, `COM-009`, `AVL-003`, `AVL-005`,
  `AVL-006`, `UX-001`, `UX-002`, `SEC-003`, `SEC-005`, `SEC-006`,
  `OPS-003`, `OPS-004`, `OPS-006`, and `OPS-007`. No requirement or gate is
  promoted.
- Candidate `0.1.45` adds the sole first-release Core schema v7, a derived exact
  endpoint lifecycle, and resumable user-level setup/update coordination.
  Endpoint identity is derived from the current
  verified human+harness credential; friendly routing freezes one exact
  endpoint and one current scope before canonical signed send. Missing,
  ambiguous, stale, revoked, cross-domain, or mismatched state fails closed,
  and activation remains `restart_required` until the user restarts and a new
  measured process proves the expected generation. Endpoint binding is fenced
  to the exact framed platform/account/pid/start-time/executable measurement;
  an executable-only measurement never proves instance identity, a new process
  instance rebinds only through the audited
  `endpoint.lifecycle.process_reconnected` transition under its verified
  harness actor, and an interrupted capability-root write is re-minted under
  owner-private custody. Only a typed task assignment may wake a semantic
  background worker; an ordinary request obligation stays durable and passively
  counted until the responsible harness answers it from its own authorized
  session.
  **In-place upgrade from `0.1.44` is not proven for this release and is not a
  supported path.** The transition code, its schema v6->v7 authority migration,
  and its rollback invariants are implemented and covered hermetically, and two
  defects found while exercising them were corrected at source: journal
  validation rejected every upgrade, and rollback safety demanded empty v7
  tables, which blocked any deployment that actually held committed v6
  communication authority. The exact packaged upgrade/rollback lane on a clean
  Ubuntu 24.04 runner remains non-green, so operators must perform a fresh
  clean install and re-enrollment rather than an in-place upgrade.
  This entry records implemented lifecycle semantics only; it adds no new
  accepted external, owner, deployment, production, signed-installer, or
  high-tier evidence and promotes no requirement or gate.
  Focused acceptance reports **454 passed and 5 expected dedicated-PostgreSQL
  skips**. The package source corpus reports **2102 passed and 21 expected
  platform/dedicated-PostgreSQL skips**, and source plus two clean recursive
  npm generations each report **2129 passed and 21 expected skips**. Browser
  invitation smoke passed the
  continuation and restart-safe completion paths. An isolated installed npm
  tarball proved exact endpoint processing, zero sibling reactions, endpoint-
  owned offline custody, no offline processing, complete endpoint/capability
  cleanup, and no workspace import fallback. Same-commit cross-platform package
  conformance and the ordinary-server clean-install lane, including live
  maintained-ClamAV readiness, are terminal-green on the pushed candidate. The
  packaged upgrade/rollback lane, staged remote
  deployment, publication, and higher-tier evidence remain separately gated.
  Affected IDs are `ARC-001`, `ARC-002`, `ARC-003`, `ID-004`, `ID-005`,
  `ID-006`, `ID-007`, `ID-008`, `ID-009`, `AUTH-001`, `AUTH-002`,
  `AUTH-003`, `AUTH-004`, `AUTH-006`, `AUTH-007`, `COM-001`, `COM-002`,
  `COM-003`, `COM-005`, `COM-006`, `COM-007`, `COM-009`, `COM-011`,
  `AVL-001`, `AVL-002`, `AVL-003`, `AVL-004`, `AVL-005`, `AVL-006`,
  `AVL-007`, `UX-001`, `UX-002`, `UX-003`, `UX-004`, `UX-006`,
  `SEC-003`, `SEC-004`, `SEC-005`, `SEC-006`, `OPS-002`, `OPS-003`,
  `OPS-004`, `OPS-005`, and `OPS-006`.

- Superseded candidate `0.1.46` repaired the ordinary-server credential-renewal timer and
  added one exact `0.1.45→0.1.46` in-place transition. The replacement schedule
  uses timer-activation-relative first activation and service-inactive-relative
  recurrence, avoiding an immediate trigger when setup runs after five minutes
  of host uptime; setup refuses operational status unless systemd exposes a
  finite future run.
  Upgrade setup quiesces the managed units before candidate package execution,
  materializes an exact generation-specific runtime as each service account,
  and validates/restarts only after those preparations, retaining the released
  runtime for bounded pre-commit rollback. The transition requires a new exact
  owner-approved plan digest and preserves the enrolled server
  identity/credential, schema-v7 PostgreSQL state, endpoint lifecycle, and
  external prerequisites. Signed clients use the platform default TLS trust
  store so the hardened services honor operator-installed private roots without
  accepting caller-controlled CA environment overrides.
  The same candidate generalizes expired-credential recovery beyond the first
  pre-C0 replacement without weakening provenance. It retains immutable C0
  terminal evidence and a canonical hash-chained supersession journal whose
  entries bind exact actor/key/file state, Approval receipt, transaction, and
  PostgreSQL audit record. Recovery, setup, and Core validate the full chain
  against current database and managed-file state. Exact replay reconciles
  response loss; missing, stale, noncanonical, unaudited, skipped-epoch,
  actor/key drift, and replay-conflicting state fail closed. The owner-approved
  same-key path grants no authority and restarts no service.
  The expanded focused release-blocker lane reports **543 passed and 5
  expected dedicated-PostgreSQL skips**; the broad releasable-source lane
  reports **2151 passed and 21 expected platform/dedicated-PostgreSQL skips**;
  and the fuller local source run reports **2259 passed and 21 expected
  skips**, with only the two deliberately non-green installed-harness pin
  checks and the pre-assembly release-manifest binding check deselected.
  Source and two recursive packed generations each report **2178 passed and
  21 expected platform/dedicated-PostgreSQL skips** after candidate reassembly.
  The earlier disposable Ubuntu timer/upgrade proof remains valid only for its
  recorded pre-supersession source tree and was not rerun as post-C0 recovery
  evidence. Publication and higher-tier evidence remain pending.
  Affected IDs are `ID-006`, `ID-009`, `AUTH-001`, `AUTH-002`, `AUTH-004`,
  `SEC-005`, `SEC-006`, `OPS-003`, `OPS-004`, and `OPS-006`. No requirement
  or must-not-ship gate is promoted.

- Candidate `0.1.48` supersedes unpublished `0.1.47`. It resolves the
  completed-C0 terminal credential from the canonical schema by joining the
  harness/epoch-scoped credential to the exact domain/principal-bound harness;
  missing or mismatched actor, harness, or epoch state remains fail-closed. It
  adds only the exact forward-only `0.1.47→0.1.48` five-unit marker transition
  for servers that already committed the unpublished `0.1.47` marker.
  Schema-v7 PostgreSQL, enrolled identity/credential, endpoint, communication,
  and external-prerequisite state remain unchanged; no database migration is
  introduced. The focused lane reports **547 passed and 5 expected
  dedicated-PostgreSQL skips**; the broad releasable-source lane reports
  **2155 passed and 21 expected platform/dedicated-PostgreSQL skips**.
  Recursive packed-package verification, installed-host upgrade evidence,
  publication, and higher-tier evidence remain pending. Affected IDs are
  `ID-006`, `ID-009`, `SEC-007`, and `OPS-003`. No requirement or
  must-not-ship gate is promoted.

- Candidate `0.1.49` removes the fresh-enrollment timing dependency from
  permanent communication activation by resolving the exact completed C0 pair.
  Only the authenticated ordinary server harness's current active credential
  may advance that same harness lineage; stale, revoked, ambiguous,
  cross-harness, and incomplete identity state remains fail-closed. Terminal
  pre-commit scope retries converge without replacing active authority. Remote
  message send, inbox, and acknowledgement operations now require and sign the
  exact collaboration scope. The candidate adds only the exact forward-only
  `0.1.48→0.1.49` five-unit marker transition and no database migration.
  The focused lane reports **645 passed and 5 expected dedicated-PostgreSQL
  skips**; the broad releasable-source lane reports **2166 passed and 21
  expected platform/dedicated-PostgreSQL skips**. Recursive packed-package
  verification and installed-host upgrade evidence remain pending.
  Publication and higher-tier evidence remain pending. Affected IDs are
  `ID-001`, `ID-002`, `ID-004`, `ID-006`, `AUTH-001`, `AUTH-002`, `AUTH-003`,
  `AUTH-004`, `AUTH-007`, `AUTH-009`, `COM-001`, `COM-002`, `COM-003`,
  `COM-006`, `COM-009`, `COM-011`, `AVL-003`, `AVL-005`, `AVL-006`, `SEC-003`,
  and `SEC-005`. No requirement or must-not-ship gate is promoted.

- Candidate `0.1.50` makes the existing setup protocol resumable through one
  guided server command and one server-origin-only laptop command. It derives
  laptop identity defaults from authenticated discovery, emits content-free
  named phases, enforces ten-minute server and five-minute laptop deadlines,
  and returns exact blocker/recovery metadata without changing authority.
  Exact v0.1.45–v0.1.49 schema-v7 five-unit markers are allowlisted direct
  sources to v0.1.50 under the existing forward-only journal; unsupported and
  ambiguous state remains fail-closed. Packed-package verification now invokes
  the separate-process local message/obligation roundtrip. The Approval service
  now purpose-gates its explicit one-hour request ceiling to
  `authorization.communication_scope.approve`; every other approval retains the
  five-minute ceiling and WebAuthn challenges remain short-lived. The focused
  release lane reports **681 passed and 5 expected dedicated-PostgreSQL skips**;
  the broad releasable-source lane reports **2180 passed and 21 expected
  platform/dedicated-PostgreSQL skips**; and source plus two recursive packed
  generations each report **2207 passed and 21 expected skips**. Two independent
  release builds are byte-identical, the release
  manifest verifier passes, and the installed tarball journey passes from an
  unrelated prefix. Installed-host, fresh-machine, and same-commit CI evidence
  remains pending. Affected IDs are `ID-006`, `AUTH-004`, `AUTH-007`, `COM-001`,
  `COM-002`, `COM-003`, `COM-006`, `COM-009`, `AVL-003`, `AVL-005`, `AVL-006`,
  `UX-001`, `UX-002`, `SEC-003`, `SEC-005`, `OPS-003`, and `OPS-006`. No
  requirement or must-not-ship gate is promoted.

- Corrective v0.1.51 work replaces the manually demonstrated live recovery
  with a package-owned, bounded path for the exact ordinary-onboarding
  placeholder-owner state. Approval owner/passkey custody and current signer
  authority converge to the enrolled Core principal only when exact domain,
  OIDC, credential, row-shape, configuration, and journal evidence agrees.
  Setup journals the corresponding Core policy cutover and resumes exact
  partial writes; unsupported or ambiguous state fails closed. Communication
  activation now materializes the complete schema-v7 collaboration projection
  atomically with scope commitment, while a committed legacy scope is repaired
  idempotently from its server-held source rows without replacement or generic
  entitlement minting. The exact v0.1.50→v0.1.51 path preserves the published
  300-second generic Approval policy without a rewrite and separately journals
  and atomically normalizes only the retained one-hour generic Approval hotfix
  to the bounded 600-second ordinary and 3600-second communication-scope TTL
  split. An unrecorded hotfix is accepted only when deriving the published
  300-second form reproduces the marker’s exact canonical config digest;
  retries resume, pre-commit rollback restores the source bytes, and any
  additional drift fails closed. The same marker gate composes the exact
  completed canonical-owner repair with the retained TTL hotfix: it validates
  terminal recovery and signer evidence, reconstructs both marker-era Approval
  and Core documents, and requires both canonical digests to match before
  creating an upgrade journal or changing managed state. Every initial or
  resumed attempt revalidates the terminal journal, exact single active owner,
  adoption audit, credential state, and signer custody before journal
  preparation or TTL migration; the retained 3600-second source shape is parsed
  without writing and only its exact allowlisted TTL delta is accepted. Setup
  then journals the realized current documents, normalizes the TTL policy, and
  verifies idempotent owner/Core convergence; incomplete, cross-principal,
  signer-drifted, ambiguous-owner, or independently drifted state remains
  fail-closed. A lost
  PostgreSQL lease heartbeat publishes reconnect-required state while protected
  operations remain excluded. A later operation opens a fresh verified
  connection and reacquires a strictly higher same-owner fence;
  different-owner contention or unverifiable recovery remains unavailable.
  The focused recovery lane reports **261 passed**; the broad
  releasable-source lane reports **2249 passed and 22 expected
  platform/dedicated-PostgreSQL skips**; and source plus two recursive packed
  generations each report **2276 passed and 22 expected skips**. Two independent
  builds are byte-identical, packaged local message/obligation processing
  reaches `recipient_committed`, and a fresh installed npm package passes exact
  endpoint routing with zero sibling reactions or residue. Exact-commit GitHub
  installed-host and disposable PostgreSQL 18.4 evidence for predecessor
  commit `4e8ebd72d6b5e39550e438816abb1e2d30a5326a` remains retained but does not
  bind this corrective source delta. Fresh same-commit CI and server PostgreSQL
  validation are required before owner-authorized live convergence. Live
  server/laptop convergence and two-machine reliability evidence remain pending.
  Affected IDs are `ID-001`, `ID-002`, `ID-005`,
  `ID-006`, `AUTH-001`, `AUTH-002`, `AUTH-003`, `AUTH-004`, `AUTH-005`,
  `COM-001`, `COM-002`, `COM-009`, `AVL-003`, `AVL-005`, `SEC-003`, `SEC-005`,
  `SEC-007`, `OPS-003`, and `OPS-006`. No requirement or must-not-ship gate is
  promoted.

- The same corrective v0.1.51 candidate adds a bounded recovery for an expired
  same-principal `member` in an active schema-v7 collaboration scope. A current
  managed-server harness of the exact scope-owning principal may initiate the
  ceremony because the expired member cannot authenticate, but the exact human
  principal remains the source of positive authority through a fresh,
  single-use Approval receipt bound to the complete scope/member/credential
  pre-state. One atomic transaction tombstones the old member, activates the
  exact replacement with the preserved role, advances counters, recomputes
  digests, and records audit evidence. Current projection membership is the
  authorization source; schema-v6 provenance remains immutable. All mismatch,
  stale, replay, partial-projection, and unsupported transfer paths fail closed;
  crash recovery reuses owner-only pending state. This changes no managed
  identity/configuration and restarts no service. Affected IDs are `ID-005`,
  `ID-006`, `ID-009`, `AUTH-001`, `AUTH-002`, `AUTH-003`, `AUTH-004`,
  `AUTH-005`, `COM-001`, `COM-002`, `COM-009`, `AVL-003`, `SEC-003`,
  `SEC-005`, `SEC-007`, `OPS-003`, and `OPS-006`. `PD-002` and all
  owner/external release gates remain blocked; no requirement or must-not-ship
  gate is promoted.




- S5/S6 directly exercise `ID-006`, `AUTH-001`, `AUTH-002`, `AUTH-003`,
  `AUTH-004`, `AUTH-007`, `COM-001`, `COM-009`, `AVL-005`, `AVL-006`, `UX-001`,
  `UX-002`, `SEC-003`, `SEC-005`, and `SEC-006`. Existing requirement status is
  not promoted solely from this bounded same-principal local proof.
- For the unreleased `0.1.12` cross-platform candidate, GitHub Actions run
  `29610467753` at commit `6d7834e` passed the named source and packed-install
  contracts on Ubuntu, macOS, and Windows. The platform suite reported
  **13 passed/8 skipped** on Ubuntu, **15 passed/6 skipped** on macOS, and
  **17 passed/4 skipped** on Windows; package checks and install/launch from an
  unrelated directory passed on every host. This is P-shaped real-host evidence
  for the exact package, state, SQLite, IPC, DACL, named-pipe, replay, capability,
  and Job Object tests only. It is not signed installer/update/uninstall,
  privileged hostile-host, semantic harness, production, owner-decision,
  first-message, enrollment, activation, or cutover evidence.
- The versioned `0.1.12` unfiltered local run reports **1122 passed and 15
  expected host/PostgreSQL skips**. `npm run check` reports source, installed
  generation 1, and repacked generation 2 each at **1043 passed and 15 expected
  skips**; package check, release verifier, and two-generation packed gate pass.
  The skips are exact non-Linux host contracts on this Linux runner plus seven
  mutation-authorized PostgreSQL cases; no skipped case is promoted.
- The retained 2026-07-13 mutation-authorized broad run reported **983 passed,
  0 failed, 0 skipped, 0 xfailed**; it remains historical local evidence.
  The last focused PostgreSQL 18.4 run likewise remains historical:
  `.venv/bin/pytest -q -p no:cacheprovider tests/production/test_postgres_runtime.py`
  reported **44 passed, 0 skipped** for the earlier schema. The `0.1.9` migration
  3 PostgreSQL lane has not been rerun locally because no disposable
  mutation-authorized database is configured. No database was changed.
- The current installed-harness probe reports **8 passed** for exact installed
  Claude `2.1.215`, Codex `0.144.5`, Pi `0.80.10`, and Antigravity `1.1.3`
  version probes plus deterministic private lifecycles on 2026-07-19. No
  semantic/model inference was performed.
- The official A2A TCK `1.0.0.alpha2` HTTP+JSON run selected 235 tests:
  **46 passed, 12 failed, 177 skipped, 0 errors**. All 12 failures were
  classified; all 177 skips were exhaustively categorized from the durable
  JUnit record by disabled binding/feature or fixture reason. The official gate
  is **not green** and no failure or skip is waived;
  see `evidence/gates/G04/2026-07-13-alpha2-http-json/manifest.json` and
  `evidence/gates/G04/2026-07-13-alpha2-http-json/REVIEW.md`.

Status vocabulary:

- `local-tested`: the cited behavior has production code and executable local
  positive plus negative/race/recovery evidence appropriate to its local scope.
- `partial-external`: substantial local implementation passes, but required
  real peer, model, platform, partner, multi-node, or production evidence is absent.
- `owner-blocked`: secure code/defaults exist, but an unsigned or unresolved
  accountable policy/ceremony decision prevents completion.
- `implementation-gap`: required behavior or evidence is genuinely absent;
  a nearby interface or test is not treated as completion.

## Current bounded-C0 traceability

This additive map records the S5/S6 repository candidate without changing any
stable requirement's status or remaining external/owner boundary.

| Stable IDs | Candidate implementation | Candidate tests | Evidence limit |
|---|---|---|---|
| `ID-006`, `AUTH-001`, `AUTH-002`, `AUTH-003`, `AUTH-004`, `AUTH-007`, `COM-009` | `src/agentnet/authorization/c0_pilot_service.py`; `src/agentnet/authorization/policy.py`; `src/agentnet/c0_pilot_http.py` | `tests/authorization/test_bootstrap_plan_service.py`; `tests/integration/test_c0_pilot_http.py` | Exact same-principal harness/credential attribution, selector denial, drift invalidation, and proof-derived actor checks are H/L only. |
| `COM-001`, `AVL-005`, `AVL-006`, `SEC-003`, `SEC-005`, `SEC-006` | `src/agentnet/authorization/c0_pilot_service.py`; `src/agentnet/mailbox/service.py`; `src/agentnet/delivery/state.py` | `tests/authorization/test_bootstrap_plan_service.py`; `tests/delivery/test_mailbox_acknowledgement.py` | Seven issuer-owned facts, authoritative event/receipt replay, idempotency, crash/audit rollback, cleanup, and terminal invalidation are local only; `accepted_local` remains mandatory. |
| `UX-001`, `UX-002` | `src/agentnet/supervisor/daemon.py`; `src/agentnet/supervisor/client.py`; `src/agentnet/supervisor/integration.py` | `tests/supervisor/test_c0_pilot_responder.py`; `tests/supervisor/test_daemon_config.py` | The dedicated responder is no-model and separate from foreground/semantic worker paths; real focus/session instrumentation remains external. |

## 85-requirement ledger

| Requirement and obligation | Status | Live production path | Executable evidence | Honest remaining boundary |
|---|---|---|---|---|
| ARC-001 — independently installable self-hosted extension | partial-external | `pyproject.toml`; `src/agentnet/cli.py`; `src/agentnet/operations/server_setup.py`; `src/agentnet/core/app.py`; `deploy/compose.production.json` | Fixed plan/apply/retry/conflict setup plus positive/negative deployment and API composition: `tests/operations/test_server_setup.py`; `tests/production/test_deployment_config.py`; `tests/integration/test_http_api.py`; update rejection: `tests/security/test_update_verifier.py` | Product-owned Linux setup has hermetic evidence only; signed platform install/uninstall, privileged clean-host apply, cleanup, and rollback evidence is absent. |
| ARC-002 — agent-agnostic owned semantics and replaceable mechanisms | partial-external | `src/agentnet/interfaces/contracts.py`; `src/agentnet/components/registry.py`; `src/agentnet/components/bakeoff.py` | Absent-component and semantic-floor rejection: `tests/operations/test_fail_closed_config.py`; `tests/operations/test_runtime_policy_enforcement.py` | Maintained-component replacement and operational bake-offs are absent. |
| ARC-003 — Claude, Codex, Pi, and Antigravity support | partial-external | `src/agentnet/adapters/specs.py`; `src/agentnet/supervisor/runtime.py`; `src/agentnet/supervisor/demos.py` | Installed deterministic 8/8: `tests/adapters/test_installed_live_inference.py`; isolation/restart: `tests/adapters/test_clean_worker_boundaries.py`; `tests/adapters/test_subprocess_lifecycle.py` | Credentialed signed clean-worker semantic evidence is absent for all four harnesses. |
| ARC-004 — native A2A interoperability | partial-external | `src/agentnet/gateways/a2a_service.py`; `src/agentnet/gateways/a2a_runtime.py`; `src/agentnet/protocol/a2a_mapping.py` | Local positive/negative/callback/recovery suites: `tests/a2a/test_persistent_service_mount.py`; `tests/a2a/test_native_client_and_callbacks.py`; `tests/a2a/test_signed_native_gateway.py`; official reviewed run: `evidence/gates/G04/2026-07-13-alpha2-http-json/manifest.json` | Official alpha2 recorded 46 passed, 12 failed, and 177 skipped; cross-SDK/public-peer/certificate evidence is absent. |
| ARC-005 — internal mechanisms need not be A2A | partial-external | `src/agentnet/mailbox/service.py`; `src/agentnet/relay/service.py`; `src/agentnet/storage/postgres.py` | Mailbox/property/relay/PostgreSQL behavior: `tests/delivery/test_mailbox.py`; `tests/property/test_delivery_state_machine_properties.py`; `tests/relay/test_server_agent_relay.py`; `tests/production/test_postgres_runtime.py` | No comparative SLIM/Matrix/workflow-engine adoption evidence exists. |
| ARC-006 — public-peer trust isolation | partial-external | `src/agentnet/gateways/a2a.py`; `src/agentnet/gateways/a2a_runtime.py`; `src/agentnet/identity/actors.py` | Unsigned proposals, signed peers, SSRF, grants, and mapping negatives: `tests/a2a/test_signed_native_gateway.py`; `tests/a2a/test_gateway_profile.py`; `tests/a2a/test_routes_and_grants.py` | Public hostile-peer and adaptive abuse campaigns are absent. |
| ID-001 — verified human principal bound to each harness | partial-external | `src/agentnet/identity/enrollment.py`; `src/agentnet/identity/oidc.py`; `src/agentnet/identity/domains.py` | OIDC subject/alias/collision and enrollment races: `tests/identity/test_oidc_enrollment.py`; `tests/identity/test_enrollment.py`; HTTP composition: `tests/integration/test_enrollment_http.py` | The ordinary PD-001 canonical-principal/reporting rule was recorded on 2026-07-19; live workforce IdP and alias migration/appeal evidence remain absent. |
| ID-002 — independently authenticated human enrollment approval | partial-external | `src/agentnet/approval/service.py`; `src/agentnet/approval/config.py`; `src/agentnet/approval/store.py`; `src/agentnet/approval/webauthn_uv.py`; `src/agentnet/approval/http.py`; `src/agentnet/approval/internal_client.py`; `src/agentnet/identity/enrollment.py`; `src/agentnet/enrollment_http.py`; `src/agentnet/_terminal_handoff.py` | Existing receipt attacks plus strict versioned approval-store migration, UV-required ceremony, host-local capability custody, strict signed internal v2 request/status/retrieval, hash-only possession binding, cumulative mismatch attempts, exact retry/conflict recovery, receipt non-disclosure, fixed remote `/activate`, zero/multiple/local/expired denial, and browser race wait: `tests/approval/test_webauthn_service.py`; `tests/approval/test_approval_http.py`; `tests/approval/test_approval_store_migration.py`; `tests/approval/test_internal_client.py`; `tests/identity/test_oidc_enrollment.py`; `tests/authorization/test_bootstrap_plan_service.py`; `tests/integration/test_enrollment_http.py`; `tests/integration/test_cli_product_journey.py`; `tests/cli/test_terminal_handoff.py` | The ordinary PD-002 WebAuthn/default-colocation policy was recorded on 2026-07-19 and automatic possession-bound delivery update on 2026-07-28. Live Google/passkey, distinct-OS-identity shared-host attack, recovery, and completed cross-device evidence remain absent. Separately administered hosting is optional high-assurance evidence, not an ordinary-onboarding prerequisite. |
| ID-003 — payload identity claims confer no trust | local-tested | `src/agentnet/identity/actors.py`; `src/agentnet/identity/context.py`; `src/agentnet/http_api.py` | Payload spoof and transport-derived actor tests: `tests/identity/test_context.py`; `tests/identity/test_actor_union.py`; `tests/integration/test_identity_admin_http.py` | Local claim rejection is proven; target-platform attribution is covered separately. |
| ID-004 — credentials cryptographically bind post-enrollment identity | partial-external | `src/agentnet/identity/credentials.py`; `src/agentnet/security/dpop.py`; `src/agentnet/security/signatures.py` | Wrong target/key, replay, rotation, and restart lineage: `tests/security/test_signatures_and_replay.py`; `tests/identity/test_credential_rotation.py`; `tests/a2a/test_persistent_service_mount.py` | Hardware/OS key custody and cross-language vectors are absent. |
| ID-005 — signing-key enrollment has an exact migration-safe ceremony | local-tested | `src/agentnet/identity/enrollment.py`; `src/agentnet/identity/oidc.py`; `src/agentnet/storage/guided_enrollment_schema.py`; `src/agentnet/cli.py`; `src/agentnet/enrollment_http.py`; `src/agentnet/_terminal_handoff.py` | Transcript/PoP/approval positives, hash-only continuation and possession binding, expiry/slow-down, wrong-token/secret/key denial, response-loss convergence, durable owner-only resumable state, zero implicit entitlements, local-system-browser compatibility, and headless fixed `/activate` remote resume without browser/TTY/code disclosure: `tests/identity/test_enrollment.py`; `tests/identity/test_oidc_enrollment.py`; `tests/integration/test_enrollment_http.py`; `tests/integration/test_cli_product_journey.py`; `tests/cli/test_terminal_handoff.py` | Local identity-only ceremony is implemented; external custody and completed live cross-host evidence remain under ID-004/009 and G06. |
| ID-006 — human and exact harness identities remain distinct | partial-external | `src/agentnet/identity/actors.py`; `src/agentnet/identity/context.py`; `src/agentnet/identity/workload.py`; `src/agentnet/bindings/composition.py` | Actor-union, sibling, workload, current-epoch local binding, and measured IPC child negatives: `tests/identity/test_actor_union.py`; `tests/identity/test_workload_identity.py`; `tests/security/test_ipc_capability.py`; `tests/bindings/test_local_binding_composition.py` | Privileged target-host same-UID/PID-reuse attribution and exact installed-harness evidence remain external. |
| ID-007 — revoke one harness without revoking siblings | partial-external | `src/agentnet/identity/revocation.py`; `src/agentnet/identity_admin_http.py`; `src/agentnet/identity/context.py` | Revocation, wrong approval, concurrent lifecycle, and admin HTTP: `tests/identity/test_revocation.py`; `tests/integration/test_identity_admin_http.py` | Real device-loss/offboarding drill and full cross-resource revocation matrix are absent. |
| ID-008 — identity is scoped to an exact trust domain | partial-external | `src/agentnet/identity/domains.py`; `src/agentnet/identity/context.py`; `src/agentnet/federation/service.py` | Cross-domain proof, pairwise guest, bilateral trust, and revocation negatives: `tests/identity/test_context.py`; `tests/federation/test_bilateral_guest.py`; `tests/federation/test_http_composition.py` | Independently administered partner-domain evidence is absent. |
| ID-009 — issuance, rotation, expiry, recovery, compromise, and offboarding | owner-blocked | `src/agentnet/identity/credentials.py`; `src/agentnet/identity/recovery.py`; `src/agentnet/identity/revocation.py`; `src/agentnet/approval/webauthn_uv.py` | Rotation/recovery/revocation positives, substitutions, replay, races, plus approval credential/request/challenge/receipt expiry and revocation: `tests/identity/test_credential_rotation.py`; `tests/identity/test_recovery.py`; `tests/identity/test_revocation.py`; `tests/approval/test_webauthn_service.py` | Real custody/recovery administrators, approval signer/authenticator rotation drill, and signed PD-005/009 lifecycle choices are absent. |
| AUTH-001 — every protected operation resolves a verified caller | partial-external | `src/agentnet/identity/context.py`; `src/agentnet/identity/workload.py`; `src/agentnet/authorization/policy.py` | Human, guest, workload, and forged-workload cases: `tests/identity/test_context.py`; `tests/identity/test_workload_identity.py`; `tests/federation/test_bilateral_guest.py`; `tests/delivery/test_mailbox.py` | Privileged transport identity evidence for deployed workloads is absent. |
| AUTH-002 — authorization consumes proof-derived identity | local-tested | `src/agentnet/security/dpop.py`; `src/agentnet/identity/context.py`; `src/agentnet/client.py`; `src/agentnet/approval/internal_broker.py`; `src/agentnet/approval/http.py` | Canonical target/body/audience/replay and client-origin negatives plus exact Core→Approval method/path/body/audience/purpose/key proof cases: `tests/security/test_signatures_and_replay.py`; `tests/security/test_signed_client.py`; `tests/identity/test_context.py`; `tests/approval/test_internal_broker.py`; `tests/approval/test_approval_http.py` | Local proof contracts are executable and fail-closed; deployed workload/TLS assurance remains external. |
| AUTH-003 — positive permissions attach to the human principal | owner-blocked | `src/agentnet/authorization/policy.py`; `src/agentnet/authorization/evidence.py`; `src/agentnet/identity_admin_http.py` | Human-only authority, signed issue/revoke, replay, and stale revision: `tests/authorization/test_policy.py`; `tests/integration/test_identity_admin_http.py`; `tests/authorization/test_authority_bootstrap.py` | Signed PD-001/003 principal and attenuation policy is absent. |
| AUTH-004 — every action retains originating harness attribution | local-tested | `src/agentnet/messaging/events.py`; `src/agentnet/identity/context.py`; `src/agentnet/audit/service.py` | HTTP actor spoof rejection and audit hash-chain attribution: `tests/integration/test_http_api.py`; `tests/identity/test_context.py`; `tests/audit/test_audit_chain.py` | Target-host assurance remains an external deployment property, not a local overclaim. |
| AUTH-005 — assignment/delegation cannot transfer another human's authority | local-tested | `src/agentnet/authorization/grants.py`; `src/agentnet/organization/assignment.py`; `src/agentnet/organization/relationships.py` | Grant dimension negatives, directional assignments, privilege noninheritance, and races: `tests/authorization/test_grants.py`; `tests/organization/test_assignment.py`; `tests/organization/test_task_custody.py` | Adaptive hostile-model trials are absent but local authority transfer is denied. |
| AUTH-006 — sensitive release/effect is policy-gated and audited | local-tested | `src/agentnet/artifacts/service.py`; `src/agentnet/effects/workflow.py`; `src/agentnet/supervisor_http.py`; `src/agentnet/audit/service.py` | Artifact release killpoints, protected task payload audit-before-disclosure/rollback/current-state retry, and effect transaction rollback/reconciliation: `tests/artifacts/test_staged_artifact.py`; `tests/adapters/test_supervisor_core_composition.py`; `tests/effects/test_effect_reservation.py`; HTTP path: `tests/integration/test_product_http_api.py` | Real data connectors/KMS/witnesses remain external; task release grants no tool/effect authority. |
| AUTH-007 — missing, stale, revoked, ambiguous state fails closed | local-tested | `src/agentnet/authorization/decision.py`; `src/agentnet/operations/outage.py`; `src/agentnet/operations/config.py`; `src/agentnet/approval/internal_broker.py`; `src/agentnet/approval/http.py`; `src/agentnet/approval/store.py`; `src/agentnet/supervisor/runtime.py` | Policy/outage/current-revision, feature-gate, malformed/stale proof, ambiguous header, replay-store/migration negatives, and MCP bootstrap socket replacement/renewal/startup/exhaustion cleanup: `tests/operations/test_runtime_policy_enforcement.py`; `tests/operations/test_fail_closed_config.py`; `tests/authorization/test_policy.py`; `tests/approval/test_internal_broker.py`; `tests/approval/test_approval_http.py`; `tests/approval/test_approval_store_migration.py`; `tests/adapters/test_subprocess_lifecycle.py` | Local uncertainty handling is explicitly tested; privileged real-host path-substitution evidence remains external. |
| AUTH-008 — temporary elevation requires independent human approval | owner-blocked | `src/agentnet/authorization/elevation.py`; `src/agentnet/approval/service.py`; `src/agentnet/approval/webauthn_uv.py`; `src/agentnet/identity_admin_http.py` | Independent receipt, UV ceremony purpose coverage, no self-approval, threshold, replay, and HTTP tests: `tests/approval/test_webauthn_service.py`; `tests/authorization/test_elevation.py`; `tests/integration/test_identity_admin_http.py` | Real independently administered approvers and signed PD-004 risk classes are absent. |
| AUTH-009 — elevation is scoped, expiring, revocable, bounded, audited | local-tested | `src/agentnet/authorization/elevation.py`; `src/agentnet/authorization/grants.py`; `src/agentnet/effects/reservations.py` | TTL/use/scope/revoke and one-use effect evidence: `tests/authorization/test_elevation.py`; `tests/authorization/test_grants.py`; `tests/effects/test_effect_reservation.py` | Connector-specific execution evidence remains external. |
| AUTH-010 — approver sets, thresholds, emergency override policy | owner-blocked | `src/agentnet/operations/policy_defaults.py`; `src/agentnet/authorization/elevation.py` | Secure floors and high-impact threshold rejection: `tests/operations/test_secure_policy_defaults.py`; `tests/authorization/test_elevation.py` | Accountable PD-004 approval and break-glass record is absent. |
| ORG-001 — multiple administrators | local-tested | `src/agentnet/organization/relationships.py`; `src/agentnet/storage/relationship_governance_schema.py` | Independently consented exact edges from multiple administrators to one subordinate, reverse edges, revisions, and reads: `tests/organization/test_relationships.py` | The local many-to-many relationship graph is executable; production policy remains under ORG-006. |
| ORG-002 — scoped downward assignment auto-queues custody only | local-tested | `src/agentnet/organization/assignment.py`; `src/agentnet/storage/task_custody_schema.py`; `src/agentnet/mailbox/service.py`; `src/agentnet/supervisor_http.py` | Only active canonical consent records auto-queue; complete-scope, direction, expiry, owner/credential/policy drift, privilege noninheritance, server-derived whole-second deadline persistence/retry stability, permanent generic-read redaction, and separate exact TaskGrant authorize→custody→release with audit-before-disclosure, no second use, response-loss retry, conflict/epoch/expiry/tamper/revocation negatives: `tests/organization/test_assignment.py`; `tests/organization/test_task_custody.py`; `tests/adapters/test_supervisor_core_composition.py` | Acceptance still records custody only. Generic paths expose a digest-bound reference, not task bytes. Protected recipient-owned release establishes exact payload/semantic authority only after the second decision; tool and effect authority remain false. |
| ORG-003 — many-to-many hierarchy without ambiguous decisions | local-tested | `src/agentnet/organization/relationships.py`; `src/agentnet/authorization/evidence.py`; `src/agentnet/organization/conflicts.py` | Exact pair isolation, multiple edges, version fencing, non-enumerating reads, renew/revoke races, and arrival-order-independent typed task-conflict holds: `tests/organization/test_relationships.py`; `tests/property/test_relationship_lifecycle.py`; `tests/organization/test_task_custody.py` | Pair authority and incompatible-instruction handling are deterministic locally. |
| ORG-004 — management never implies data authority | local-tested | `src/agentnet/organization/assignment.py`; `src/agentnet/mailbox/service.py`; `src/agentnet/messaging/conversation.py`; `src/agentnet/authorization/policy.py`; `src/agentnet/supervisor_http.py` | Exact activation provenance and assignment prove custody-only outputs; task/task-linked-control payloads stay withheld from generic reads; protected release requires recipient-owned exact grant/current intent/local custody and denies wrong recipient, dimension drift, stale epochs, conflicts, expiry, tamper, missing intent, and revocation: `tests/organization/test_relationships.py`; `tests/organization/test_assignment.py`; `tests/organization/test_task_custody.py`; `tests/messaging/test_conversation_semantics.py`; `tests/authorization/test_policy.py`; `tests/adapters/test_supervisor_core_composition.py` | Management still grants no data, tool, credential, budget, network, artifact, or effect authority. Current release is exact payload/semantic authority only. |
| ORG-005 — directional assignment and conflicting instructions | local-tested | `src/agentnet/organization/assignment.py`; `src/agentnet/organization/conflicts.py`; `src/agentnet/product_http.py`; `src/agentnet/messaging/conversation.py`; `src/agentnet/gateways/a2a_runtime.py` | Downward exact-scope auto-queue; upward/lateral `pending_human`; complete typed resource intent; arrival-order and true-concurrency conflict holds; simultaneous opposite adjudications with one winner; overlapping staged release; shared terminal-rejection propagation and automatic settlement; admission/adjudication serialization; exact subordinate-owner partition; wrong-owner, stale-epoch, incompatible-release, replay, expiry, cancellation, authenticated HTTP, and two-store real-PostgreSQL race evidence: `tests/organization/test_assignment.py`; `tests/organization/test_task_custody.py`; `tests/integration/test_product_http_api.py`; `tests/production/test_postgres_runtime.py`; `tests/messaging/test_conversation_semantics.py`; `tests/a2a/test_persistent_service_mount.py`; `tests/relay/test_server_agent_relay.py` | Conflicting open members atomically become `conflict_pending`; exact-version owner release returns only to queued custody and explicitly grants no data, semantic, tool, or effect authority. |
| ORG-006 — authenticated relationship lifecycle governance | owner-blocked | `src/agentnet/organization/relationships.py`; `src/agentnet/approval/service.py`; `src/agentnet/product_http.py`; `src/agentnet/storage/relationship_governance_schema.py` | Zero-authority proposal; exact verifier-derived subordinate human/guest-owner consent; wrong purpose/owner/domain/transaction/replay/drift negatives; one-use signed human/guest exception; exact pending-to-completed local activation intent for either basis; authority denial after intent deletion/tamper or signer guest/grant/credential revocation; injected transaction rollback; activation-versus-signed-revocation races; expiry, subject exit, admin override, and authenticated HTTP renewal where the old exact receipt is rejected, fresh v2 consent atomically supersedes v1, replay is rejected, and assignment revisions fence correctly; complete clean schema-v1 SQLite/PostgreSQL creation/tamper checks: `tests/organization/test_relationships.py`; `tests/property/test_relationship_lifecycle.py`; `tests/integration/test_product_http_api.py`; `tests/production/test_postgres_runtime.py` | The activation intent is durable local provenance, not an independent witness. Eligible proposers and proposal-entitlement policy, exception/override authorities and thresholds, mandatory relationships, notice/review/appeal, retention, real independent approver/audit-witness deployment, and accountable owner approval do not exist. |
| COM-001 — direct enrolled-agent communication | local-tested | `src/agentnet/core/app.py`; `src/agentnet/messaging/events.py`; `src/agentnet/mailbox/service.py` | Direct HTTP positive, spoof/replay negatives, offline reconcile, and exact recipient custody acknowledgement: `tests/integration/test_http_api.py`; `tests/integration/test_mailbox_acknowledgement_http.py`; `tests/delivery/test_mailbox.py`; `tests/delivery/test_mailbox_acknowledgement.py` | Production durability is evaluated separately. |
| COM-002 — intermittent agents communicate with ordinary server agents | partial-external | `src/agentnet/http_api.py`; `src/agentnet/client.py`; `src/agentnet/supervisor/client.py` | Signed client/API, exact mailbox acknowledgement target/body binding, and autonomous supervisor integration: `tests/security/test_signed_client.py`; `tests/integration/test_http_api.py`; `tests/integration/test_mailbox_acknowledgement_http.py`; `tests/adapters/test_supervisor_core_composition.py` | Real remote TLS/client deployment and target-host credentials are absent. |
| COM-003 — ordinary server agents deliver to enrolled agents | partial-external | `src/agentnet/supervisor/integration.py`; `src/agentnet/supervisor/daemon.py`; `src/agentnet/supervisor_http.py` | Authenticated live watch with bounded cursor fallback, redacted durable queue custody before exact protected payload release, result-before-release denial, automatic durable obligation reconciliation, retry/restart, and stall watchdog: `tests/adapters/test_offline_queue_integration.py`; `tests/adapters/test_supervisor_core_composition.py`; `tests/supervisor/test_live_delivery_watch.py`; `tests/supervisor/test_daemon_config.py` | Four-harness semantic clean-worker evidence remains absent. |
| COM-004 — ordinary server-agent relay | partial-external | `src/agentnet/relay/service.py`; `src/agentnet/relay/http.py`; `src/agentnet/relay/composition.py` | Two-agent offline/reconnect, mounted round trip, crash/duplicate/tamper/revocation/receipt recovery: `tests/relay/test_server_agent_relay.py` | Independent network/certificate/failure-domain deployment evidence is absent. |
| COM-005 — one-to-many, many-to-one, and many-to-many delivery | local-tested | `src/agentnet/identity/recipients.py`; `src/agentnet/mailbox/service.py`; `src/agentnet/messaging/events.py` | Recipient snapshot, nonexistent/cross-domain/revoked negatives, per-recipient facts: `tests/identity/test_recipient_resolution.py`; `tests/delivery/test_mailbox.py`; room fanout: `tests/rooms/test_room_authority.py` | Pressure/capacity is an operations gap, not a correctness claim. |
| COM-006 — corporate direct conversations | local-tested | `src/agentnet/messaging/conversation.py`; `src/agentnet/product_http.py` | Signed create/post/thread positive and malformed/spoof/rollback negatives: `tests/messaging/test_conversation_http.py`; `tests/messaging/test_conversation_semantics.py` | Local conversation semantics are implemented. |
| COM-007 — bidirectional manager communication with directional task custody | local-tested | `src/agentnet/organization/assignment.py`; `src/agentnet/storage/task_custody_schema.py` | Downward auto-queue; peer/upward pending; approval/deny/race/drift: `tests/organization/test_assignment.py`; `tests/organization/test_task_custody.py` | No data/effect authority is inherited. |
| COM-008 — persistent rooms and temporary meetings | local-tested | `src/agentnet/rooms/service.py`; `src/agentnet/rooms/meetings.py`; `src/agentnet/product_http.py` | Create/membership/speaker/guest/state/transfer and HTTP tests: `tests/rooms/test_room_authority.py`; `tests/integration/test_product_http_api.py` | Maintained MLS is separately gated. |
| COM-009 — contributions identify principal and harness | local-tested | `src/agentnet/messaging/events.py`; `src/agentnet/identity/actors.py`; `src/agentnet/gateways/a2a_runtime.py` | Actor union, signed HTTP attribution, public-peer low-trust mapping: `tests/identity/test_actor_union.py`; `tests/integration/test_http_api.py`; `tests/a2a/test_signed_native_gateway.py` | External UI presentation is not claimed. |
| COM-010 — room governance/history/transfer/guest/archive policy | owner-blocked | `src/agentnet/rooms/governance.py`; `src/agentnet/rooms/service.py`; `src/agentnet/rooms/mls.py` | Membership epochs, frozen transfer, tombstone, history floors, guest restrictions: `tests/rooms/test_room_authority.py`; HTTP fencing: `tests/integration/test_product_http_api.py` | Signed PD-006/007 governance, retention, and MLS adoption is absent. |
| COM-011 — threads, replies, mentions, tasks, handoffs, cancellation, completion | local-tested | `src/agentnet/messaging/conversation.py`; `src/agentnet/protocol/models.py` | Positive semantics, malformed/spoof negatives, rollback, cancellation/completion acknowledgements: `tests/messaging/test_conversation_semantics.py`; `tests/messaging/test_conversation_http.py` | Local typed semantics are implemented. |
| FILE-001 — first-class attachments in required topologies | partial-external | `src/agentnet/artifacts/service.py`; `src/agentnet/protocol/models.py`; `src/agentnet/product_http.py`; `src/agentnet/client.py`; `src/agentnet/cli.py` | Direct/conversation/HTTP attachment binding plus bounded binary operator upload/download: `tests/integration/test_product_http_api.py`; `tests/messaging/test_conversation_semantics.py`; `tests/security/test_signed_client.py`; `tests/cli/test_artifact_cli.py`; cross-domain quarantine hold: `tests/relay/test_server_agent_relay.py` | Real object backend, safe supervisor-managed harness staging, and every external topology are absent. |
| FILE-002 — artifact operations are identity/policy bound | local-tested | `src/agentnet/artifacts/service.py`; `src/agentnet/authorization/policy.py`; `src/agentnet/client.py`; `src/agentnet/cli.py` | Reserve/upload/scan/release/download positive; exact raw-body proof, caller-owned stable input, exclusive private output, wrong actor/policy/single-use and release crash boundaries: `tests/artifacts/test_staged_artifact.py`; `tests/integration/test_product_http_api.py`; `tests/security/test_signed_client.py`; `tests/cli/test_artifact_cli.py` | Local authorization and audit ordering are tested; maintained scanner and production storage evidence remain external. |
| FILE-003 — artifacts survive offline periods | partial-external | `src/agentnet/artifacts/service.py`; `src/agentnet/storage/recovery.py`; `src/agentnet/storage/postgres.py` | Release recovery and manifest/byte cross-check: `tests/artifacts/test_staged_artifact.py`; `tests/production/test_postgres_runtime.py`; relay reconnect hold: `tests/relay/test_server_agent_relay.py` | Replicated object storage, PITR, and long-offline restoration are absent. |
| FILE-004 — artifact integrity and provenance | partial-external | `src/agentnet/artifacts/service.py`; `src/agentnet/artifacts/scanner.py`; `src/agentnet/security/signatures.py` | Digest conflict, signed scanner identity/key/rules/policy drift, object/version binding: `tests/artifacts/test_staged_artifact.py` | Cross-language provenance and independent scanner/store evidence are absent. |
| FILE-005 — storage, quota, retention, deletion, version, dedup, legal hold | partial-external | `src/agentnet/artifacts/service.py`; `src/agentnet/storage/artifact_quota_schema.py`; `src/agentnet/operations/policy_defaults.py` | Atomic cumulative actor/domain byte charging, abort/expiry/delete reconciliation, cross-instance race, version/legal-hold/retention gates, guarded unlink, and same-plaintext non-disclosure: `tests/artifacts/test_staged_artifact.py`; `tests/production/test_postgres_runtime.py`; HTTP: `tests/integration/test_product_http_api.py` | Replicated object host-loss backup/restore is external; signed retention/deletion/legal policy is owner-blocked. |
| FILE-006 — malware/secret/executable content safety | partial-external | `src/agentnet/artifacts/scanner.py`; `src/agentnet/artifacts/service.py` | Pre-storage executable/archive/EICAR/secret/media-mismatch rejection with content-free denial plus signed-attestation freshness/key/rules/substitution negatives: `tests/artifacts/test_staged_artifact.py`; config trust: `tests/production/test_deployment_config.py` | Maintained third-party scanner/corpus and privileged hostile-file sandbox evidence remain external. |
| AVL-001 — laptop and continuously available ordinary-agent profiles | local-tested | `src/agentnet/operations/config.py`; `src/agentnet/operations/server_setup.py`; `src/agentnet/supervisor/daemon.py`; `src/agentnet/core/app.py` | Profile fail-closed tests, setup interruption/rerun, installed deterministic lifecycles, and deployment topology: `tests/operations/test_fail_closed_config.py`; `tests/operations/test_server_setup.py`; `tests/adapters/test_installed_live_inference.py`; `tests/production/test_deployment_config.py` | Local profile distinction and hermetic setup state transitions are executable; privileged live-host operation remains external. |
| AVL-002 — offline is normal, not revocation | local-tested | `src/agentnet/mailbox/service.py`; `src/agentnet/presence/service.py`; `src/agentnet/supervisor/queue.py` | Offline queue/reconnect and signed stale presence: `tests/adapters/test_offline_queue_integration.py`; `tests/presence/test_signed_lease.py`; `tests/relay/test_server_agent_relay.py` | Offline and identity states remain distinct. |
| AVL-003 — durable offline store-and-forward | partial-external | `src/agentnet/storage/postgres.py`; `src/agentnet/mailbox/service.py`; `src/agentnet/relay/service.py` | Mutation-authorized real-PostgreSQL tests prove two-instance mailbox visibility and reconnect-only-next-operation fencing: `tests/production/test_postgres_runtime.py`; duplicate/crash/reconnect: `tests/relay/test_server_agent_relay.py` | Multi-node HA/failover/PITR/RPO and replicated artifact storage remain external. |
| AVL-004 — reliable always-on baseline plus future eligible peer assistance | partial-external | `src/agentnet/relay/service.py`; `src/agentnet/mesh/distributed.py`; `src/agentnet/mailbox/custodian.py` | Ordinary one-hop relay and fail-closed distributed mode: `tests/relay/test_server_agent_relay.py`; `tests/operations/test_fail_closed_config.py` | Multi-relay quorum/partition/revocation semantics remain disabled and unproven. |
| AVL-005 — explicit accepted/queued/delivered/acknowledged/expired/rejected/failed facts | local-tested | `src/agentnet/delivery/state.py`; `src/agentnet/mailbox/service.py` | Declared-graph property tests, terminal absorption, actor-owned transitions, and exact `recipient_committed` acknowledgement without presentation/processing/effect promotion: `tests/property/test_delivery_state_machine_properties.py`; `tests/delivery/test_mailbox.py`; `tests/delivery/test_mailbox_acknowledgement.py`; `tests/integration/test_mailbox_acknowledgement_http.py` | Local fact ownership is executable. |
| AVL-006 — retries, idempotency, replay, expiry, cancellation, effect uncertainty | local-tested | `src/agentnet/delivery/state.py`; `src/agentnet/security/replay.py`; `src/agentnet/supervisor_http.py`; `src/agentnet/effects/workflow.py`; `src/agentnet/approval/internal_broker.py`; `src/agentnet/approval/store.py` | Replay/idempotency, concurrent/restart-safe acknowledgement convergence, exact payload-release response-loss retry, and Core→Approval fresh-proof-nonce retry with unchanged business idempotency: `tests/security/test_signatures_and_replay.py`; `tests/delivery/test_mailbox.py`; `tests/delivery/test_mailbox_acknowledgement.py`; `tests/adapters/test_supervisor_core_composition.py`; `tests/effects/test_effect_reservation.py`; `tests/approval/test_internal_client.py`; `tests/approval/test_approval_store_migration.py` | At-least-once transport with explicit effect uncertainty and separate transport/business retry layers is implemented locally. |
| AVL-007 — failover, replication, split brain, recovery, distributed partitions | partial-external | `src/agentnet/storage/postgres.py`; `src/agentnet/storage/recovery.py`; `src/agentnet/mesh/distributed.py` | Multi-host read-write-target DSN validation, reconnect fencing, standby/future-schema/divergent-primary rejection, and disabled distributed-mode checks: `tests/production/test_postgres_runtime.py`; `tests/operations/test_fail_closed_config.py` | Independent HA cluster failover, split-brain, PITR, quorum, and measured recovery evidence remain external. |
| AVL-008 — authenticated bounded-freshness presence | local-tested | `src/agentnet/presence/service.py`; `src/agentnet/discovery/directory.py` | Signed current harness lease, stale/recent/live/unknown, and directory visibility negatives: `tests/presence/test_signed_lease.py`; `tests/discovery/test_non_enumerating_directory.py` | Local presence semantics are tested. |
| UX-001 — communication uses separate background sessions | partial-external | `src/agentnet/supervisor/runtime.py`; `src/agentnet/supervisor/integration.py`; `src/agentnet/supervisor/workers.py` | Installed deterministic private lifecycles, process restart, autonomous dispatch: `tests/adapters/test_installed_live_inference.py`; `tests/adapters/test_subprocess_lifecycle.py`; `tests/adapters/test_offline_queue_integration.py` | Credentialed semantic sessions for all four installed harnesses are absent. |
| UX-002 — background work never injects or steals foreground flow | partial-external | `src/agentnet/adapters/specs.py`; `src/agentnet/supervisor/runtime.py` | No foreground methods, sanitized private processes, deterministic installed runs: `tests/adapters/test_all_harnesses.py`; `tests/adapters/test_clean_worker_boundaries.py`; `tests/adapters/test_installed_live_inference.py` | Exact focus/input/context instrumentation under real semantic traffic is absent. |
| UX-003 — minimal passive indication | local-tested | `src/agentnet/adapters/status.py`; `src/agentnet/supervisor/service.py`; `src/agentnet/supervisor/queue.py` | Content-free installed lifecycle summary, queue counts, and encrypted restart-durable obligation counters: `tests/adapters/test_installed_live_inference.py`; `tests/supervisor/test_background_queue.py`; `tests/adapters/test_offline_queue_integration.py` | Supported local indication is content-free. |
| UX-004 — routine indication is non-interactive and content-free | local-tested | `src/agentnet/adapters/status.py`; `src/agentnet/attention/policy.py` | Secret-content absence and silent-default tests: `tests/supervisor/test_background_queue.py`; `tests/operations/test_privacy_budgets_attention.py` | Local routine behavior is proven. |
| UX-005 — exceptional attention policy | owner-blocked | `src/agentnet/attention/policy.py`; `src/agentnet/operations/policy_defaults.py` | Silent default, exact exception catalog, stricter runtime behavior: `tests/operations/test_privacy_budgets_attention.py`; `tests/operations/test_runtime_policy_enforcement.py`; `tests/operations/test_secure_policy_defaults.py` | Signed PD-011 channels, quiet hours, escalation, and redaction policy is absent. |
| UX-006 — fallback for limited harness capabilities | partial-external | `src/agentnet/adapters/capabilities.py`; `src/agentnet/adapters/specs.py`; `src/agentnet/supervisor/live_gate.py` | Per-harness manifest/spec, deterministic fallback, missing-evidence hard failure: `tests/adapters/test_all_harnesses.py`; `tests/adapters/test_launch_specs.py`; `tests/adapters/test_installed_live_inference.py` | Semantic fallback evidence on each exact harness remains absent. |
| FED-001 — bilateral multi-company capability | partial-external | `src/agentnet/federation/service.py`; `src/agentnet/federation_http.py`; `src/agentnet/federation/trust.py` | Bilateral signatures, HTTP admission/use, unilateral-key negatives, dual revocation: `tests/federation/test_bilateral_guest.py`; `tests/federation/test_http_composition.py` | No independently administered partner lab exists. |
| FED-002 — scoped outbound contractor access | partial-external | `src/agentnet/federation/service.py`; `src/agentnet/federation/trust.py` | Home assertion, host acceptance, scoped invitation and wrong-key negatives: `tests/federation/test_bilateral_guest.py`; `tests/federation/test_http_composition.py` | Real outbound use of another company's network is absent. |
| FED-003 — temporary minimal inbound contractor identity | partial-external | `src/agentnet/federation/service.py`; `src/agentnet/identity/context.py` | Pairwise guest harness/key/credential admission, forged assertion, revoke: `tests/federation/test_bilateral_guest.py`; HTTP route: `tests/federation/test_http_composition.py` | External partner identity proof/reproof is absent. |
| FED-004 — guest least privilege by resource/action/time/domain | local-tested | `src/agentnet/federation/service.py`; `src/agentnet/authorization/grants.py` | Ceiling/assurance, source/sink/resource/time, domain, and immediate revoke negatives: `tests/federation/test_bilateral_guest.py`; `tests/federation/test_http_composition.py` | Local guest grant enforcement is tested. |
| FED-005 — no transitive trust | local-tested | `src/agentnet/federation/trust.py`; `src/agentnet/federation/service.py`; `src/agentnet/relay/service.py` | Direct bilateral domain enforcement plus explicit three-domain onward/back-home relay attempts with valid local peer/grant state: `tests/federation/test_bilateral_guest.py`; `tests/relay/test_server_agent_relay.py` | Local non-transitivity is executable; independently administered partner evidence remains under FED-001/009. |
| FED-006 — every federated operation carries exact host context | local-tested | `src/agentnet/federation/service.py`; `src/agentnet/identity/context.py` | Guest actor domain/key/audience binding, wrong domain, and atomic operation tests: `tests/federation/test_bilateral_guest.py`; `tests/federation/test_http_composition.py` | Local host-context enforcement is tested. |
| FED-007 — selected bilateral federation model remains replaceable | partial-external | `src/agentnet/federation/trust.py`; `src/agentnet/interfaces/contracts.py`; `src/agentnet/federation_http.py` | Exact trust config, disabled/inert rejection, full local HTTP flow: `tests/federation/test_http_composition.py`; `tests/operations/test_fail_closed_config.py` | Comparative operational federation bake-off is absent. |
| FED-008 — configurable external identity assurance/reproof | owner-blocked | `src/agentnet/federation/service.py`; `src/agentnet/operations/policy_defaults.py` | Assurance-floor/ceiling and wrong proof tests: `tests/federation/test_bilateral_guest.py`; policy floors: `tests/operations/test_secure_policy_defaults.py` | Signed PD-008 per-partner/resource/action assurance is absent. |
| FED-009 — cross-domain audit/revocation/incident behavior | owner-blocked | `src/agentnet/federation/service.py`; `src/agentnet/federation_http.py`; `src/agentnet/audit/service.py` | Signed monotonic duplicate-safe home/host revocation and HTTP tests: `tests/federation/test_bilateral_guest.py`; `tests/federation/test_http_composition.py` | Independent partner incident drill and signed PD-009 SLO/outage policy are absent. |
| SEC-001 — threat model covers stated adversaries and abuse | partial-external | `src/agentnet/identity/context.py`; `src/agentnet/authorization/policy.py`; `src/agentnet/security/update.py`; `docs/THREAT_MODEL_TEST_PLAN.md` | Cross-cutting negative/race/recovery suites: `tests/security/test_signatures_and_replay.py`; `tests/identity/test_workload_identity.py`; `tests/effects/test_effect_reservation.py`; `tests/relay/test_server_agent_relay.py` | No complete adaptive hostile-model/red-team campaign or independent review artifact exists. |
| SEC-002 — transport, at-rest, and optional end-to-end encryption policy | partial-external | `src/agentnet/security/envelope.py`; `src/agentnet/rooms/mls.py`; `deploy/nginx-agent.conf`; `src/agentnet/operations/policy_defaults.py` | Encrypted stores, TLS topology, sealed-room adoption failure, and policy floors: `tests/delivery/test_mailbox.py`; `tests/production/test_deployment_config.py`; `tests/rooms/test_room_authority.py`; `tests/operations/test_runtime_policy_enforcement.py` | Independent KMS/key ceremony, maintained MLS lifecycle, and real TLS deployment evidence are absent. |
| SEC-003 — tamper-evident enrollment/access/effect/federation audit | partial-external | `src/agentnet/audit/service.py`; `src/agentnet/authorization/policy.py`; `src/agentnet/organization/relationships.py`; `src/agentnet/artifacts/service.py` | Hash chain/checkpoint, release/effect rollback, enrollment/federation audit paths, and exact completed local relationship-activation intent/tamper denial: `tests/audit/test_audit_chain.py`; `tests/organization/test_relationships.py`; `tests/artifacts/test_staged_artifact.py`; `tests/effects/test_effect_reservation.py`; `tests/federation/test_bilateral_guest.py` | Relationship activation has durable local provenance only. Independent witness, omission/fork reconciliation, restore, and production retention evidence are absent. |
| SEC-004 — privacy/minimization for content and metadata | owner-blocked | `src/agentnet/privacy/classes.py`; `src/agentnet/operations/telemetry.py`; `src/agentnet/attention/policy.py` | Sensitive-label rejection, aggregate persistence, content-free status, stricter classification behavior: `tests/operations/test_privacy_budgets_attention.py`; `tests/operations/test_runtime_policy_enforcement.py`; `tests/supervisor/test_background_queue.py` | Signed PD-006/007/010/011 retention, indexing, residency, and disclosure policy is absent. |
| SEC-005 — nonce/time/sequence freshness and replay windows | local-tested | `src/agentnet/security/freshness.py`; `src/agentnet/security/replay.py`; `src/agentnet/bindings/ipc.py`; `src/agentnet/supervisor/model_egress.py`; `src/agentnet/approval/internal_broker.py`; `src/agentnet/approval/store.py` | Clock/target/replay, signed mailbox-ack replay, persistent IPC restart, model-egress per-capability request-nonce consumption/race rejection, persistent Core→Approval one-use proof custody across duplicate/concurrent/reopen cases, and A2A duplicate behavior: `tests/security/test_signatures_and_replay.py`; `tests/integration/test_mailbox_acknowledgement_http.py`; `tests/security/test_ipc_capability.py`; `tests/supervisor/test_clean_workers_and_model_broker.py`; `tests/approval/test_internal_broker.py`; `tests/approval/test_internal_client.py`; `tests/approval/test_approval_store_migration.py`; `tests/approval/test_approval_http.py`; `tests/a2a/test_signed_native_gateway.py` | Local freshness/replay semantics are executable. |
| SEC-006 — compromise containment, quarantine, rotation, safe restoration | partial-external | `src/agentnet/identity/revocation.py`; `src/agentnet/identity/recovery.py`; `src/agentnet/operations/outage.py`; `src/agentnet/operations/backup.py`; `src/agentnet/artifacts/service.py` | Revoke/recover/rotate, scanner quarantine, outage, signed exact SQLite backup/restore, forged/stale/revoked seal and filesystem-race negatives, and crash recovery: `tests/identity/test_revocation.py`; `tests/identity/test_recovery.py`; `tests/operations/test_backup_restore.py`; `tests/artifacts/test_staged_artifact.py`; `tests/operations/test_runtime_policy_enforcement.py` | Catastrophic root rebuild, independently administered backup custody/KMS, PostgreSQL locked restore runner, external kill-switch SLO, and production restore drill are absent. |
| SEC-007 — extension signing/update/supply-chain/sandbox trust | partial-external | `src/agentnet/security/update.py`; `src/agentnet/security/distribution.py`; `src/agentnet/supervisor/workers.py`; `src/agentnet/windows_security.py`; `deploy/Dockerfile` | Threshold/expiry/rollback/freeze/equivocation, atomic signed lifecycle contracts, durable anti-rollback, cleanup recovery, pinned health execution, private Windows DACL/reparse rejection, and worker isolation: `tests/security/test_update_verifier.py`; `tests/security/test_distribution_lifecycle.py`; `tests/platform/test_host_support.py`; `tests/adapters/test_clean_worker_boundaries.py` | Real-host package/local contracts exist for Linux/macOS/Windows. Independent signing/root ceremony, SBOM/provenance publication, signed native installer/update/uninstall, rollback, and privileged hostile-host lifecycle evidence remain external. |
| OPS-001 — separable, replaceable ordinary-agent authority/mailbox/policy/artifact/effect/gateway/audit roles | partial-external | `src/agentnet/core/app.py`; `src/agentnet/storage/postgres.py`; `src/agentnet/relay/service.py`; `src/agentnet/interfaces/contracts.py` | Main composition, one real-PostgreSQL cross-instance mailbox case, two-agent relay, and symmetric deployment tests: `tests/integration/test_product_http_api.py`; `tests/production/test_postgres_runtime.py`; `tests/relay/test_server_agent_relay.py`; `tests/production/test_deployment_config.py` | Real-PostgreSQL lifecycle, redundant failure domains, independent role credentials, failover, and replacement drills are absent. |
| OPS-002 — authenticated non-enumerating discovery | local-tested | `src/agentnet/discovery/directory.py`; `src/agentnet/presence/service.py`; `src/agentnet/product_http.py` | Agents/rooms/domains/endpoints epoch rotation, policy visibility, harness denial, plaintext rejection: `tests/discovery/test_non_enumerating_directory.py`; `tests/integration/test_product_http_api.py` | Local discovery behavior is tested. |
| OPS-003 — negotiation, compatibility, rolling upgrade, partial adapters | partial-external | `src/agentnet/protocol/negotiation.py`; `src/agentnet/operations/versioning.py`; `src/agentnet/operations/config_migration.py`; `src/agentnet/storage/migrations/__init__.py`; `src/agentnet/storage/sqlite.py`; `src/agentnet/storage/guided_enrollment_schema.py`; `src/agentnet/storage/bootstrap_plan_schema.py` | Immutable unsupported-event quarantine/replay, expand-migrate-verify-contract rollout, exact Core v4→v5 N/N-1 and Approval v1/v2/v3→v4 catalog/checksum-verified atomic migrations, injected rollback, immutable prior checksums, contiguous five-migration PostgreSQL catalog, one-use migration, concurrent-open convergence, and config rebinding: `tests/operations/test_versioning_runtime.py`; `tests/protocol/test_version_negotiation.py`; `tests/production/test_postgres_runtime.py`; `tests/identity/test_oidc_enrollment.py`; `tests/approval/test_approval_store_migration.py` | Core migration 5 and Approval schema v4 are locally tested for SQLite but not against the current mutation-authorized PostgreSQL lane; independently deployed mixed-version peers and production deprecation evidence remain external. |
| OPS-004 — privacy-safe health/queue/latency/error/denial/security observability | partial-external | `src/agentnet/operations/telemetry.py`; `src/agentnet/audit/service.py`; `src/agentnet/product_http.py` | Fixed-label counters, bounded latency buckets, gauges, outage denials, scanner/audit/cost/adapter results, and protected content-free operator status: `tests/operations/test_privacy_budgets_attention.py`; `tests/integration/test_product_http_api.py`; `tests/production/test_postgres_runtime.py` | Production dashboard, alert delivery, retention, and load-SLO evidence remain external/owner-governed. |
| OPS-005 — quotas, rate limits, backpressure, abuse and loop controls | partial-external | `src/agentnet/operations/quotas.py`; `src/agentnet/supervisor/model_egress.py`; `src/agentnet/operations/policy_defaults.py` | Persistent multidimensional fairness, atomic authoritative pressure reservations, circuit-breaker CAS/reclaim, loop fencing, safety reserve, relay/effect composition, and real-PostgreSQL one-winner race: `tests/operations/test_privacy_budgets_attention.py`; `tests/relay/test_server_agent_relay.py`; `tests/effects/test_effect_reservation.py`; `tests/production/test_postgres_runtime.py` | Production flood/soak/capacity tuning remains external and owner-governed. |
| OPS-006 — portable self-hosted install/config/credentials/deployment | partial-external | `npm/bin/agentnet.mjs`; `src/agentnet/host.py`; `src/agentnet/host_security.py`; `src/agentnet/windows_security.py`; `src/agentnet/_terminal_handoff.py`; `src/agentnet/cli.py`; `src/agentnet/operations/server_setup.py`; `src/agentnet/storage/sqlite.py`; `src/agentnet/security/distribution.py`; `deploy/compose.production.json` | Linux/macOS/Windows package install/launch; fixed Linux setup plan/apply/resume/redaction; canonical state roots; owner-mode/protected-DACL state; reparse/link rejection; portable SQLite reopen/replay; signed HTTP client availability; config rebinding; backup/restore; anti-rollback; POSIX private-TTY behavior; and one ephemeral Ubuntu 24.04/PostgreSQL 18 installed-artifact setup lifecycle with always-run cleanup: `tests/platform/test_host_support.py`; `tests/operations/test_server_setup.py`; `tests/conformance/test_npm_package.py`; `tests/cli/test_terminal_handoff.py`; `tests/production/test_deployment_config.py`; `tests/operations/test_backup_restore.py`; `tests/security/test_distribution_lifecycle.py`; GitHub run `30155733937` | Current real-host setup proof is one ephemeral Linux/systemd runner, not a privileged hostile-path or persistent-host trial. Windows terminal mode intentionally fails closed; signed native installer/update/uninstall/rollback, privileged hostile-path trials, live Google/WebAuthn, PostgreSQL locked restore, KMS/off-host custody, and independently signed production artifacts remain external. |
| OPS-007 — conformance/security/recovery/federation/harness tests and reuse bake-off | partial-external | `src/agentnet/components/bakeoff.py`; `src/agentnet/components/registry.py`; `scripts/verify_release.py`; `.github/workflows/cross-platform.yml`; `.github/workflows/server-setup-e2e.yml`; `docs/BAKEOFF_PLAN.md` | Historical cross-platform evidence remains bound to its named immutable releases. For current candidate `0.1.39`, the setup/recovery lane reports `224 passed`; focused release lane reports `645 passed/7 expected dedicated-PostgreSQL skips`; source-only lane reports `1615 passed/16 expected skips`; source and both clean recursive installed npm generations each report `1642 passed/16 expected skips`; generation 2 additionally passes the installed-byte real-loopback multiprocess local communication gate with `accepted_local`, exact attribution, idempotency, `recipient_committed`, typed obligation completion across four Core starts (three restarts), lab-fixture credential refusal, listener release, empty workspace, and no package-tree residue; direct disposable-package verification, release verification, complete package-tree equality, no-residue checks, and deterministic byte-identical archives pass. Those lanes exclude installed-live-inference, subprocess-lifecycle, and bake-off-evidence files; the two installed-harness pin failures remain non-green and unwaived. Published `0.1.38` retains ordinary 30-attempt probes, uses the existing finite 90-attempt startup bound only for public Approval/Core health and Core readiness, and admits only exact forward-only `0.1.37→0.1.38` five-unit recovery. Candidate `0.1.39` changes to explicit GET plus product User-Agent and JSON Accept headers and repairs only the deterministic-lab local policy/recipient/custody seams; production policy still rejects those harnesses. It adds no migration edge and rejects an exact 0.1.38 marker. Its same-commit gate must realize that exact public marker from fresh state, require two identical fail-closed refusals, and prove marker, attempt, managed files, database schema, unit states, identity, and authority remain unchanged. The earlier clean Ubuntu 24.04/PostgreSQL 18 setup/cleanup and cross-platform package results remain bound to named `0.1.26` commit/runs: `tests/platform/test_host_support.py`; `tests/operations/test_server_setup.py`; `tests/conformance/test_npm_package.py`; `tests/conformance/test_release_manifest.py`; `tests/production/test_postgres_runtime.py`; `tests/components/test_bakeoff_evidence.py` | Official A2A remains non-green. Exact public `0.1.39` root-installed Hub verification and fresh clean-state setup, same-commit CI, mutation-authorized PostgreSQL evidence, completed live ceremony, independent component bake-offs, adaptive red-team, privileged host trials, and production chaos remain external. |

## Accountable policy decisions (separate from the 85 requirements)

The executable defaults below prevent silent weakening, but none is a signed
owner decision. All 11 therefore remain `owner-blocked` and cannot be promoted
by local tests.

| Decision | Secure executable default | Code and local evidence | Missing owner evidence |
|---|---|---|---|
| PD-001 | Opaque domain principal keyed by issuer/subject; verified email is alias/history | `src/agentnet/operations/policy_defaults.py`; `tests/operations/test_secure_policy_defaults.py`; `tests/identity/test_oidc_enrollment.py` | Canonical-principal, migration, collision, appeal, and alias policy signature. |
| PD-002 | Fresh independent exact-transaction approval; harness cannot self-approve | `src/agentnet/approval/service.py`; `tests/identity/test_oidc_enrollment.py`; `tests/authorization/test_authority_bootstrap.py` | Approved devices/channels, recovery owners, expiry, throttling, and ceremony signature. |
| PD-003 | Harness/device/session state is deny-only attenuation | `src/agentnet/operations/policy_defaults.py`; `tests/operations/test_runtime_policy_enforcement.py`; `tests/authorization/test_policy.py` | Approved posture inputs, classifications, appeals, and exception ownership. |
| PD-004 | Independent approval; high-impact threshold cannot be reduced; break-glass off | `src/agentnet/authorization/elevation.py`; `src/agentnet/operations/policy_defaults.py`; `tests/authorization/test_elevation.py` | Risk classes, approver sets, TTL/use limits, and emergency policy signature. |
| PD-005 | Revocation blocks next decision; uncertain compromise is quarantined | `src/agentnet/identity/revocation.py`; `src/agentnet/operations/policy_defaults.py`; `tests/identity/test_revocation.py` | Event-class preservation/erasure/hold matrix and compromise adjudicator signature. |
| PD-006 | One room authority, from-join history, frozen transfer, tombstone on lost authority | `src/agentnet/rooms/governance.py`; `src/agentnet/operations/policy_defaults.py`; `tests/rooms/test_room_authority.py` | Governance, guest/history, deletion, retention, and legal-hold signature. |
| PD-007 | Managed lower classifications; sealed rooms disabled without adopted MLS evidence | `src/agentnet/rooms/mls.py`; `src/agentnet/operations/policy_defaults.py`; `tests/rooms/test_room_authority.py`; `tests/operations/test_runtime_policy_enforcement.py` | Sealed-room launch, model-provider, training, retention, and residency signature. |
| PD-008 | Bilateral home proof; host-local stronger reproof for high risk | `src/agentnet/federation/service.py`; `src/agentnet/operations/policy_defaults.py`; `tests/federation/test_bilateral_guest.py` | Per-partner/resource/class/action assurance and reproof signature. |
| PD-009 | Host revoke at next decision; issuance stops during outage; privileged hold | `src/agentnet/operations/outage.py`; `src/agentnet/federation/service.py`; `tests/operations/test_runtime_policy_enforcement.py`; `tests/federation/test_bilateral_guest.py` | Token TTL, revocation SLO, outage ceiling, backlog, and continuity signature. |
| PD-010 | No false multiregion/RPO claim; immutable production images; bounded retention | `src/agentnet/operations/policy_defaults.py`; `deploy/compose.production.json`; `tests/production/test_deployment_config.py`; `tests/production/test_postgres_runtime.py` | OS/architecture, topology, RPO/RTO, residency, quota, staffing, backup, and legal ownership signature. |
| PD-011 | Routine traffic silent; exceptional notices content-free and allowlisted | `src/agentnet/attention/policy.py`; `src/agentnet/operations/policy_defaults.py`; `tests/operations/test_privacy_budgets_attention.py` | Channels, quiet hours, escalation, redaction, and accountable attention-policy signature. |

## Install-and-use dependency reconciliation

Reconciled on 2026-07-16 without promoting any requirement or gate. The 85-row
status vocabulary measures each stable acceptance criterion at its stated
scope; it does not imply that the assembled company product is installable or
that a nearby interface is a finished integration. The remaining product work
has this fail-closed dependency order:

1. **Outbound OIDC connection binding (`ID-001..004`, `AUTH-002/007`,
   `SEC-001/005/006`, `OPS-006`).** The direct transport now resolves once per
   server request, validates the canonical address snapshot, connects only to
   one of those numeric addresses, and preserves exact hostname TLS/SNI and Host
   verification while refusing proxies and redirects. A real socket-path
   rebinding negative provides local H evidence. Production enrollment remains
   blocked on real IdP/TLS and independent-boundary L/E/O evidence, not this
   former local implementation gap.
2. **Explicit self-hosted/private/confidential OIDC policy (same IDs).** The
   public `none` default remains. Confidential clients select exactly
   `client_secret_post` or `client_secret_basic`, reference only a runtime
   environment name, require discovery advertisement, and never infer a method
   from secret presence. A private provider additionally requires exact HTTPS
   origins, exact JWK pins, canonical address/CIDR pins, and connection-time
   enforcement. Local Google multi-origin, PKCE, redaction, rotation, migration,
   IPv4/IPv6, and deployment-config tests pass; real provider operation remains
   unproven.
3. **WebAuthn-UV ceremony deployment (`ID-002/009`, `AUTH-008..010`,
   `ORG-006`, `SEC-003/005/006`).** Current source includes a separately
   runnable registration/UV/origin/RP-ID/display/signing/expiry/revocation
   service covering every mandatory mounted purpose and issuing the existing
   strict receipt. The ordinary profile now permits Core/PostgreSQL/approval
   colocation under distinct OS identities and reports
   `independent_boundary_proven=false`; it still needs live TLS, Google,
   passkey, shared-host attack, rotation, and recovery evidence. Separate
   physical/administrative hosting remains an optional high-assurance tier.
4. **Activation and lifecycle productization (`ARC-001`, `ID-006/007/009`,
   `OPS-001/003/006`).** First server-agent binding, supervisor configuration,
   install/update/uninstall/rollback, principal offboarding, and all four exact
   harness activations must be explicit supported commands rather than operator
   integration work.
5. **Protected delegated execution (`ORG-002/004/005`, `COM-007/011`,
   `AUTH-005..007`).** Current source now implements the smallest protected
   payload/semantic path: exact recipient `task.process` authorization consumes
   one event/resource/mailbox/receipt/classification-bound grant use; redacted
   local custody precedes release; one audit/receipt commits before disclosure;
   retries fresh-check actor, credential, domain, policy, grant, intent,
   conflict, lifetime, digests, and provenance without another use; result
   upload requires that receipt. Generic reads remain redacted and tool/effect
   authority remains false. Still missing for full delegated execution are
   separately modeled tool, network-origin, budget, credential, artifact,
   protected-output, and business-effect grants plus real clean-worker evidence.
6. **Production mechanisms and evidence (`FILE-*`, `AVL-003/004/007`,
   `SEC-002/003/006/007`, `OPS-001/004..007`).** PostgreSQL HA/PITR/restore,
   replicated object custody, scanner attestations, key custody, policy runtime,
   audit witness, observability, clean workers, A2A conformance, and signed
   distribution remain component/evidence gates, not tasks for an operator to
   implement.
7. **External and owner gates.** Required P/E/O evidence and PD-001..PD-011 plus
   ORG-006 remain distinct from product engineering. Safe defaults permit
   reversible implementation and tests but never count as owner consent.

This ordering is not a new requirement baseline. It makes cross-row product
integration gaps explicit so “0 implementation-gap” cannot be misread as
“install-and-use complete.”

## Totals and release boundary

Requirement totals: **33 local-tested, 42 partial-external, 10 owner-blocked,
0 implementation-gap = 85 unique requirements**. Policy-decision totals:
**11 owner-blocked = 11 separate PD records**.

The release remains blocked. Local evidence does not substitute for semantic
four-harness trials, a green official A2A gate and cross-SDK/public peers,
independent enrollment/approval and partner administrators, HA/PITR/RPO/RTO,
maintained scanner/object/KMS/audit roots, hostile-model campaigns, signed
platform packaging, or accountable PD signatures.
